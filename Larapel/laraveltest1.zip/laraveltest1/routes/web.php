<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Controller;

Route::get('/', function () {
    return view('welcome');
});


Route::get('tujuh',[Controller::class, 'fungsihello']);
Route::get('Delapan/{id}/{nama}/{satuan}',[Controller::class,'terimadataget']);