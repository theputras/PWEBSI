<h3>Hasil Sebelum Diskon:</h3>
<p>Harga Sebelum Diskon: Rp <?php echo e(number_format($harga, 2, ',', '.')); ?></p>
<p>Persen Diskon: <?php echo e($persenDiskon); ?>%</p>
<h3>Hasil Setelah Diskon:</h3>
<p>Harga Setelah Diskon: Rp <?php echo e(number_format($hargaSetelahDiskon, 2, ',', '.')); ?></p>
<a href="/tampilform">Kembali ke Form</a>
<?php /**PATH D:\Github\PWEBSI\Larapel\laraveltest1\resources\views/hasilDiskon.blade.php ENDPATH**/ ?>