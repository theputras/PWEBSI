<p><?php echo e($fahrenheit); ?> °F</p>
<h3>Hasil Konversi:</h3>
<p><?php echo e($celsius); ?> °C</p>
<!-- <a href="/tampilform">Kembali ke Form</a> -->





<?php /**PATH D:\Github\PWEBSI\Larapel\laraveltest1\resources\views/hasilKonversi.blade.php ENDPATH**/ ?>