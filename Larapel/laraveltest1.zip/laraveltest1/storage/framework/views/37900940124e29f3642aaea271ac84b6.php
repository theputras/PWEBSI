<h3>Hasil Konversi:</h3>
<p><?php echo e($meter); ?> m</p>
<p>Hasil Konversi: <?php echo e($sentimeter); ?> cm</p>
<a href="/tampilform">Kembali ke Form</a>
<?php /**PATH D:\Github\PWEBSI\Larapel\laraveltest1\resources\views/hasilKonversiMeter.blade.php ENDPATH**/ ?>