<?php
echo $isix;
?>
<h1>
<?php echo e($isix); ?>

</h1>
<h1>
<?php echo e($isiy); ?>

</h1>
<h1>
<?php $__currentLoopData = $isiz; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $xx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo e($xx); ?><br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</h1>

<h1>
<?php $__currentLoopData = $isik; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $xxx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo e($xxx); ?><br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</h1>
<?php echo e($isik["mobile"]); ?><?php /**PATH D:\Github\PWEBSI\Larapel\laraveltest1\resources\views/tampil.blade.php ENDPATH**/ ?>