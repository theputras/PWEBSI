<form action="/konversifahrenheit" method="POST">
    <?php echo csrf_field(); ?>
    <input type="text" name="fahrenheit" placeholder="Masukkan Fahrenheit">
    <button type="submit">Konversi</button>
</form>
<?php /**PATH D:\Github\PWEBSI\Larapel\laraveltest1\resources\views/konversiFahrenheit.blade.php ENDPATH**/ ?>