<html>

<body>
    <form action="/terimadata" method="POST">
        <input type="hidden" name="_token" value="<?php echo csrf_token() ?>">
        <input type="text" name="nilai1">
        <br>
        <input type="text" name="nilai2">
        <br>
        <select name="operator" id="operator">
            <option value="tambah">+</option>
            <option value="kurang">-</option>
            <option value="kali">x</option>
            <option value="bagi">:</option>
        </select>
        <br>
        <input type="submit" name="proses" value="Proses">
</body>

</html><?php /**PATH D:\Github\PWEBSI\Larapel\laraveltest1\resources\views/viewkedua.blade.php ENDPATH**/ ?>