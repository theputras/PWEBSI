<html>
<body>
<h2>Data Array Buah</h2>
<ul>
    <?php $__currentLoopData = $buah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($b); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
</body>
</html>
<?php /**PATH D:\Github\PWEBSI\Larapel\laraveltest1\resources\views/array.blade.php ENDPATH**/ ?>