<html>
<body>
<h2>Data Karyawan</h2>
<table border="1" cellpadding="5">
    <tr><th>ID</th><th>Nama</th><th>Jabatan</th></tr>
    <?php $__currentLoopData = $karyawan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($k['id']); ?></td>
            <td><?php echo e($k['nama']); ?></td>
            <td><?php echo e($k['jabatan']); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</body>
</html>
<?php /**PATH D:\Github\PWEBSI\Larapel\laraveltest1\resources\views/karyawan.blade.php ENDPATH**/ ?>