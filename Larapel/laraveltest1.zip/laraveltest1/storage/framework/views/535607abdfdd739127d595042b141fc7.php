<form action="/hitungnilaiakhir" method="POST">
    <?php echo csrf_field(); ?>
    <input type="text" name="uts" placeholder="Masukkan Nilai UTS">
    <input type="text" name="uas" placeholder="Masukkan Nilai UAS">
    <input type="text" name="tugas" placeholder="Masukkan Nilai Tugas">
    <button type="submit">Hitung Nilai Akhir</button>
</form>
<?php /**PATH D:\Github\PWEBSI\Larapel\laraveltest1\resources\views/hitungNilaiAkhir.blade.php ENDPATH**/ ?>