<h3>Hasil Nilai Awal:</h3>
<p>Nilai Tugas: <?php echo e(number_format($tugas, 2, ',', '.')); ?></p>
<p>Nilai UTS: <?php echo e(number_format($uts, 2, ',', '.')); ?></p>
<p>Nilai UAS: <?php echo e(number_format($uas, 2, ',', '.')); ?></p>
<h3>Hasil Nilai Akhir:</h3>
<p>Nilai Akhir: <?php echo e(number_format($nilaiAkhir, 2, ',', '.')); ?></p>
<!-- <a href="/tampilform">Kembali ke Form</a> -->
<?php /**PATH D:\Github\PWEBSI\Larapel\laraveltest1\resources\views/hasilNilaiAkhir.blade.php ENDPATH**/ ?>