<html>
<body>
<h2>Data Supplier</h2>
<table border="1" cellpadding="5">
    <tr><th>ID</th><th>Nama</th><th>Kota</th></tr>
    <?php $__currentLoopData = $supplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($s['id']); ?></td>
            <td><?php echo e($s['nama']); ?></td>
            <td><?php echo e($s['kota']); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</body>
</html>
<?php /**PATH D:\Github\PWEBSI\Larapel\laraveltest1\resources\views/supplier.blade.php ENDPATH**/ ?>