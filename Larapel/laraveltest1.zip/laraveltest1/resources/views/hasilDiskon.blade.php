<h3>Hasil Sebelum Diskon:</h3>
<p>Harga Sebelum Diskon: Rp {{ number_format($harga, 2, ',', '.') }}</p>
<p>Persen Diskon: {{ $persenDiskon }}%</p>
<h3>Hasil Setelah Diskon:</h3>
<p>Harga Setelah Diskon: Rp {{ number_format($hargaSetelahDiskon, 2, ',', '.') }}</p>
<!-- <a href="/tampilform">Kembali ke Form</a> -->
