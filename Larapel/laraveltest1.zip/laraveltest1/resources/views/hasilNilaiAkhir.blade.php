<h3>Hasil Nilai Awal:</h3>
<p>Nilai Tugas: {{ number_format($tugas, 2, ',', '.') }}</p>
<p>Nilai UTS: {{ number_format($uts, 2, ',', '.') }}</p>
<p>Nilai UAS: {{ number_format($uas, 2, ',', '.') }}</p>
<h3>Hasil Nilai Akhir:</h3>
<p>Nilai Akhir: {{ number_format($nilaiAkhir, 2, ',', '.') }}</p>
<!-- <a href="/tampilform">Kembali ke Form</a> -->
