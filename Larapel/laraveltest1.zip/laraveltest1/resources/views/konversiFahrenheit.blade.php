<form action="/konversifahrenheit" method="POST">
    @csrf
    <input type="text" name="fahrenheit" placeholder="Masukkan Fahrenheit">
    <button type="submit">Konversi</button>
</form>
