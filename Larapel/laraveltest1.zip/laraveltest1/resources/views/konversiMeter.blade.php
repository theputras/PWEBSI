<form action="/konversimeter" method="POST">
    @csrf
    <input type="text" name="meter" placeholder="Masukkan Meter">
    <button type="submit">Konversi</button>
</form>
