<h3>Hasil Konversi:</h3>
<p>{{ $meter }} m</p>
<p>Hasil Konversi: {{ $sentimeter }} cm</p>
<!-- <a href="/tampilform">Kembali ke Form</a> -->
