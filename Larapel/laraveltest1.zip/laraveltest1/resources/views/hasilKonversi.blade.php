<p>{{ $fahrenheit }} °F</p>
<h3>Hasil Konversi:</h3>
<p>{{ $celsius }} °C</p>
<!-- <a href="/tampilform">Kembali ke Form</a> -->





