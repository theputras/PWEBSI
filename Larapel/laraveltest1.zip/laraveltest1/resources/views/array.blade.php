<html>
<body>
<h2>Data Array Buah</h2>
<ul>
    @foreach($buah as $b)
        <li>{{ $b }}</li>
    @endforeach
</ul>
</body>
</html>
