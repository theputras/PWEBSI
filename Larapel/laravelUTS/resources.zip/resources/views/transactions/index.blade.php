@extends('layouts.app')

@section('title', 'Transaction List')

@section('content')
    <div class="container">
        <h1 class="my-4" style="color: var(--secondary-color);">Transaction List</h1>
        <a href="{{ route('transactions.create') }}" class="btn btn-primary mb-3">Add New Transaction</a>

        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Warehouse</th>
                    <th>Vehicle</th>
                    <th>Quantity</th>
                    <th>Delivery Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($transactions as $transaction)
                <tr>
                    <td>{{ $transaction->product->name }}</td>
                    <td>{{ $transaction->warehouse->name }}</td>
                    <td>{{ $transaction->vehicle->name }}</td>
                    <td>{{ $transaction->quantity }}</td>
                    <td>{{ $transaction->delivery_date }}</td>
                    <td>
                        <a href="{{ route('transactions.edit', $transaction->id) }}" class="btn btn-warning btn-sm">Edit</a>
                        <form action="{{ route('transactions.destroy', $transaction->id) }}" method="POST" style="display:inline-block;">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection
