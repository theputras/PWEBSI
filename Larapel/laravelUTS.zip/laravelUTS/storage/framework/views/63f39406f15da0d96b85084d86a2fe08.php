

<?php $__env->startSection('title', 'Vehicle List'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1 class="my-4 text-center" style="color: var(--secondary-color);">Vehicle List</h1>

        <div class="mb-3">
            <a href="<?php echo e(route('vehicles.create')); ?>" class="btn btn-primary">Add New Vehicle</a>
        </div>

        <div class="card">
            <div class="card-header">
                Daftar Kendaraan
            </div>
            <div class="card-body">
                <table class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>Vehicle Plate</th>
                            <th>Vehicle Name</th>
                            <th>Vehicle Type</th>
                            <th>Year</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($vehicle->nopol); ?></td>
                            <td><?php echo e($vehicle->nama_kendaraan); ?></td>
                            <td><?php echo e($vehicle->jenis_kendaraan); ?></td>
                            <td><?php echo e($vehicle->tahun); ?></td>
                            <td>
                                <a href="<?php echo e(route('vehicles.edit', $vehicle->nopol)); ?>" class="btn btn-warning btn-sm">Edit</a>
                                <form action="<?php echo e(route('vehicles.destroy', $vehicle->nopol)); ?>" method="POST" style="display:inline-block;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Github\PWEBSI\Larapel\laravelUTS\resources\views/vehicles/index.blade.php ENDPATH**/ ?>