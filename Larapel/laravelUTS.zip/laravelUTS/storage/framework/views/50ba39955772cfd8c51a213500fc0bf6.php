

<?php $__env->startSection('title', isset($warehouse) ? 'Edit Warehouse' : 'Create Warehouse'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1 class="my-4 text-center" style="color: var(--secondary-color);"><?php echo e(isset($warehouse) ? 'Edit Warehouse' : 'Create Warehouse'); ?></h1>

        <form action="<?php echo e(isset($warehouse) ? route('warehouses.update', $warehouse->kodegudang) : route('warehouses.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php if(isset($warehouse)): ?>
                <?php echo method_field('PUT'); ?>  <!-- Untuk update -->
            <?php endif; ?>

            <div class="mb-3">
                <label for="kodegudang" class="form-label">Warehouse Code</label>
                <input type="text" name="kodegudang" class="form-control" id="kodegudang" value="<?php echo e(isset($warehouse) ? $warehouse->kodegudang : old('kodegudang')); ?>" required>
            </div>
            <div class="mb-3">
                <label for="namagudang" class="form-label">Warehouse Name</label>
                <input type="text" name="namagudang" class="form-control" id="namagudang" value="<?php echo e(isset($warehouse) ? $warehouse->namagudang : old('namagudang')); ?>" required>
            </div>
            <div class="mb-3">
                <label for="alamat" class="form-label">Address</label>
                <input type="text" name="alamat" class="form-control" id="alamat" value="<?php echo e(isset($warehouse) ? $warehouse->alamat : old('alamat')); ?>" required>
            </div>
            <div class="mb-3">
                <label for="kontak" class="form-label">Contact</label>
                <input type="text" name="kontak" class="form-control" id="kontak" value="<?php echo e(isset($warehouse) ? $warehouse->kontak : old('kontak')); ?>" required>
            </div>
            <div class="mb-3">
                <label for="kapasitas" class="form-label">Capacity</label>
                <input type="number" name="kapasitas" class="form-control" id="kapasitas" value="<?php echo e(isset($warehouse) ? $warehouse->kapasitas : old('kapasitas')); ?>" required>
            </div>
            <button type="submit" class="btn btn-primary"><?php echo e(isset($warehouse) ? 'Update Warehouse' : 'Add Warehouse'); ?></button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Github\PWEBSI\Larapel\laravelUTS\resources\views/warehouses/form.blade.php ENDPATH**/ ?>