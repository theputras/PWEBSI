

<?php $__env->startSection('title', 'Warehouse List'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1 class="my-4 text-center" style="color: var(--secondary-color);">Warehouse List</h1>

        <div class="mb-3">
            <a href="<?php echo e(route('warehouses.create')); ?>" class="btn btn-primary">Add New Warehouse</a>
        </div>

        <div class="card">
            <div class="card-header">
                Daftar Gudang
            </div>
            <div class="card-body">
                <table class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>Warehouse Code</th>
                            <th>Warehouse Name</th>
                            <th>Location</th>
                            <th>Kontak</th>
                            <th>kapasitas</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($warehouse->kodegudang); ?></td>
                            <td><?php echo e($warehouse->namagudang); ?></td>
                            <td><?php echo e($warehouse->alamat); ?></td>
                            <td><?php echo e($warehouse->kontak); ?></td>
                            <td><?php echo e($warehouse->kapasitas); ?></td>
                            <td>
                                <a href="<?php echo e(route('warehouses.edit', $warehouse->kodegudang)); ?>" class="btn btn-warning btn-sm">Edit</a>
                                <form action="<?php echo e(route('warehouses.destroy', $warehouse->kodegudang)); ?>" method="POST" style="display:inline-block;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Github\PWEBSI\Larapel\laravelUTS\resources\views/warehouses/index.blade.php ENDPATH**/ ?>