

<?php $__env->startSection('title', 'Transaction List'); ?>

<?php $__env->startSection('content'); ?>
    <?php
        // Ambil filter 'jenis' dari URL, default-nya 'REKAP'
        $jenis = request('jenis', 'REKAP');
    ?>

    <div class="container">
        <h1 class="my-4 text-center" style="color: var(--secondary-color);">Transaction List</h1>

        <div class="mb-3">
            <a href="<?php echo e(route('transactions.create')); ?>" class="btn btn-primary">Add New Transaction</a>
        </div>

        <!-- FORM FILTER (Sudah dibenahi agar 'sticky') -->
        <form method="GET" action="<?php echo e(route('transactions.index')); ?>">
            <div class="row mb-3">
                <div class="col-md-2">
                    <label for="tgl_awal" class="form-label">Start Date</label>
                    <!-- Tampilkan value filter yang lama -->
                    <input type="date" name="tgl_awal" class="form-control" value="<?php echo e(request('tgl_awal')); ?>">
                </div>
                <div class="col-md-2">
                    <label for="tgl_akhir" class="form-label">End Date</label>
                    <input type="date" name="tgl_akhir" class="form-control" value="<?php echo e(request('tgl_akhir')); ?>">
                </div>
                <div class="col-md-2">
                    <label for="jenis" class="form-label">Type</label>
                    <select name="jenis" class="form-control">
                        <!-- Cek $jenis untuk 'selected' -->
                        <option value="REKAP" <?php echo e($jenis == 'REKAP' ? 'selected' : ''); ?>>REKAP</option>
                        <option value="DETAIL" <?php echo e($jenis == 'DETAIL' ? 'selected' : ''); ?>>DETAIL</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <label for="nopol" class="form-label">Nopol</label>
                    <select name="nopol" class="form-control">
                        <option value="ALL">ALL</option>
                        <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <!-- 'selected' jika nopol di URL = nopol di loop -->
                            <option value="<?php echo e($vehicle->nopol); ?>" <?php echo e(request('nopol') == $vehicle->nopol ? 'selected' : ''); ?>>
                                <?php echo e($vehicle->nopol); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <label for="kodegudang" class="form-label">Warehouse</label>
                    <select name="kodegudang" class="form-control">
                        <option value="ALL">ALL</option>
                        <?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <option value="<?php echo e($warehouse->kodegudang); ?>" <?php echo e(request('kodegudang') == $warehouse->kodegudang ? 'selected' : ''); ?>>
                                <?php echo e($warehouse->namagudang); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-2 d-flex align-items-end">
                    <button type="submit" class="btn btn-success w-100">Filter</button>
                </div>
            </div>
        </form>

        <div class="card">
            <div class="card-header">
                Daftar Pengiriman (Mode: <?php echo e($jenis); ?>)
            </div>
            <div class="card-body">
                
                <!-- TAMPILAN JIKA MODE REKAP (SUMMARY) -->
                <?php if($jenis == 'REKAP'): ?>
                    <table class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>Shipping Code</th>
                                <th>Delivery Date</th>
                                <th>Vehicle</th>
                                <th>Driver</th>
                                <th>Total Qty</th>
                                <th>Actions</th> <!-- Actions HANYA ada di mode REKAP -->
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($transaction->kodepengiriman); ?></td>
                                <td><?php echo e($transaction->tglpengiriman); ?></td>
                                <!-- Panggil relasi 'vehicle' -->
                                <td><?php echo e($transaction->vehicle->nama_kendaraan ?? $transaction->nopol); ?></td>
                                <td><?php echo e($transaction->driver); ?></td>
                                <td><?php echo e($transaction->totalqty); ?></td>
                                <td>
                                    <a href="<?php echo e(route('transactions.edit', $transaction->kodepengiriman)); ?>" class="btn btn-warning btn-sm">Edit</a>
                                    <form action="<?php echo e(route('transactions.destroy', $transaction->kodepengiriman)); ?>" method="POST" style="display:inline-block;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="text-center">No transactions found.</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>

                <!-- TAMPILAN JIKA MODE DETAIL -->
                <?php else: ?>
                    <table class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>Shipping Code</th>
                                <th>Delivery Date</th>
                                <th>Vehicle</th>
                                <th>Product</th>
                                <th>Warehouse</th>
                                <th>Qty</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <!-- Loop di dalam loop (Master-Detail) -->
                                <!-- 'products' adalah nama relasi di Model Transaction Anda -->
                                <?php $__currentLoopData = $transaction->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($transaction->kodepengiriman); ?></td>
                                    <td><?php echo e($transaction->tglpengiriman); ?></td>
                                    <td><?php echo e($transaction->vehicle->nama_kendaraan ?? $transaction->nopol); ?></td>
                                    
                                    <!-- INI PERBAIKAN UTAMANYA -->
                                    <td><?php echo e($product->nama); ?></td>
                                    <!-- 'warehouse' adalah nama relasi di Model Product Anda -->
                                    <td><?php echo e($product->warehouse->namagudang ?? 'N/A'); ?></td>
                                    <!-- 'pivot->qty' adalah 'qty' dari tabel detailkirim -->
                                    <td><?php echo e($product->pivot->qty); ?></td> 
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="text-center">No transactions found.</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
                
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Github\PWEBSI\Larapel\laravelUTS\resources\views/transactions/index.blade.php ENDPATH**/ ?>