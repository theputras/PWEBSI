<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;

class pert9Controller extends Controller
{
    public function tugasSelect()
    {
    $pengiriman = DB::table('masterkirim as mk')
    ->join('kendaraan as k', 'mk.nopol', '=', 'k.nopol')
    ->select(
        'mk.kodekirim',
        'mk.tglkirim as tanggal',
        'k.namakendaraan as kendaraan',
        'mk.nopol',
        'k.namadriver as driver',
        'mk.totalqty'
    )
    ->get()
    ->map(function ($item) {
        // Get detail pengiriman for each masterkirim
        $details = DB::table('detailkirim as dk')
            ->join('produk as p', 'dk.kodeproduk', '=', 'p.kodeproduk')
            ->where('dk.kodekirim', $item->kodekirim)
            ->select(
                'p.kodeproduk as kode',
                'p.nama as namaproduk',
                'p.satuan',
                'dk.qty'
            )
            ->get()
            ->toArray();

        return [
            'kodekirim' => $item->kodekirim,
            'tanggal' => $item->tanggal,
            'kendaraan' => $item->kendaraan,
            'nopol' => $item->nopol,
            'driver' => $item->driver,
            'totalqty' => $item->totalqty,
            'detailpengiriman' => $details
        ];
    })
    ->toArray();
}
}